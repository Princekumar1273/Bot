<div align="center">
  <h1>Discord-Bot</h1
  <p>A discord bot with alot of features.....<p>
</div>

### Check New Bot: https://github.com/Uo1428/Mutli-Discord-Bot 


![image](https://img.youtube.com/vi/yuyZPfslrsw/maxresdefault.jpg) 

# [ALL IN ONΞ™](https://discord.uoaio.xyz)
## [YouTube](https://tinyurl.com/3jvb65tv)
### [Support Server](https://discord.uoaio.xyz)

# How to setup the bot?
- Watch YouTube Video: [click here](https://www.youtube.com/watch?v=yuyZPfslrsw)
---

### 💘 Emotes Servers 

* 1.0: https://discord.gg/RjHTDAQHkR
* 2.0: https://discord.gg/g7T8KUrmyt
* 2.1.0: https://discord.gg/fmhTFzruzP
* 3.0: https://discord.gg/hpwuhE2vVE
* 3.1.0: https://discord.gg/M7DWTrYEWZ

### 💕Credit
- Code By Techpoint Development 
- Modified By @uoaio - .gg/uoaio

## ✨ Discord Profile
<div align="center">
  <a width="100%" href="https://discord.uoaio.xyz/"  target="_blank">
    <img align="mid" height="100%" width="100%" style="margin: 0 10px 0 0;" alt=" " src="https://discord.c99.nl/widget/theme-2/922120042651451423.png">
  </a>
</div>


<div align="center">
  <p>Your One Click Can Help This Repo To Grow MorE: Leave a star ⭐<p>
</div>

